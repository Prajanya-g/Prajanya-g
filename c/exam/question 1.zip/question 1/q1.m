name = input("Please enter your name ",'s');
fprintf("Enter the year of study for %s", name);
year =  input(" ");
fprintf("Enter the id for %s", name);
studentId = input(" ",'s');

fprintf("Student info for year %d:\n", year);
fprintf("name: %s \n", name);
fprintf("id: %s\n", studentId);